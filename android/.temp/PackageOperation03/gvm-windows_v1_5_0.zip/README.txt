This package contains drivers needed to run Android Emulator on AMD platform
without Windows Hypervisor Platform (WHPX).

It is recommended to use Windows command console with administrator privilege.

"silent_install.bat" will install the driver.
"silent_install.bat -u" will uninstall the driver.